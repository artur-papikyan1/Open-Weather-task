import styles from "./WeatherChosen.module.scss";
import { useEffect, useState } from "react";

export const WeatherChosen = () => {
  const [currentWeather, setCurrentWeather] = useState([]);
  const [isLoading, setIsLoading] = useState();

  useEffect(() => {
    setIsLoading(false);
    fetch(
      "https://api.openweathermap.org/data/2.5/weather?q=Yerevan&appid=4437e2b2b2bcf7bea17d5111c325d7b0&units=metric",
    )
      .then((response) => response.json())
      .then((result) => setCurrentWeather(result))
      .catch(() => {
        setIsLoading(true);
      });
  }, []);

  return (
    <div className={styles.weatherChosen}>
      {isLoading ? (
        <div>
          <h1>{currentWeather.name}</h1>
          <span>{Math.round(currentWeather.main.temp)}</span>
          <span>{currentWeather.weather[0].main}</span>
          <img
            src={`https://openweathermap.org/img/wn/${currentWeather.weather[0].icon}@2x.png`}
            alt=""
          />
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};
