import { useEffect, useState } from "react";

import styles from "./Weathers.module.scss";

export const Weathers = () => {
  const [weather, setWeather] = useState([]);
  const [isActive, setIsActive] = useState(null);

  useEffect(() => {
    let cancelled = false;

    fetch(
      "https://api.openweathermap.org/data/2.5/forecast?q=%D0%95%D1%80%D0%B5%D0%B2%D0%B0%D0%BD&appid=4437e2b2b2bcf7bea17d5111c325d7b0&units=metric&cnt=5",
    )
      .then((response) => response.json())
      .then((data) => {
        if (!cancelled) {
          setWeather(data.list);
        }
      })
      .catch(() => {
        // TODO: handle error
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const handleClick = (item) => {
    setIsActive(item);
  };

  return (
    <div className={styles.weathers}>
      {weather.map((item) => (
        <button /*button for accessibility*/
          className={styles.weathersItem}
          key={item.dt}
          onClick={() => {
            handleClick(item);
          }}
          data-active={item === isActive ? "active" : ""}
        >
          <span>{Math.round(item.main.temp)}</span>
          <span>{item.weather[0].main}</span>
          <img
            src={`https://openweathermap.org/img/wn/${item.weather[0].icon}@2x.png`}
            alt=""
          />
          <span>{item.dt_txt}</span>
        </button>
      ))}
    </div>
  );
};
