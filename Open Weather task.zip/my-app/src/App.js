import "./css/reset.scss";
import "./App.css";

import { WeatherChosen } from "./components/WeatherChosen/WeatherChosen";
import { Weathers } from "./components/Weathers/Weathers";
import { Header } from "./components/Header/Header";

function App() {
  return (
    <div className="App">
      <Header />
      <section>
        <WeatherChosen />
        <Weathers />
      </section>
    </div>
  );
}

export default App;
